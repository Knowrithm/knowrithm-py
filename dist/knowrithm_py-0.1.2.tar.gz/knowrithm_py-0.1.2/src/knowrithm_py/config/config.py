
class Config:
    # KNOWRITHM_BASE_URL = 'https://app.knowrithm.org/api'
    KNOWRITHM_BASE_URL = 'http://localhost:8543/api'
    