
class Config:
    KNOWRITHM_BASE_URL = 'https://app.knowrithm.org/api'
    