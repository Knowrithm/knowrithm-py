
import os


class Config:
    # KNOWRITHM_BASE_URL = os.getenv('KNOWRITHM_BASE_URL')
    KNOWRITHM_BASE_URL = 'https://app.knowrithm.org/api'
    