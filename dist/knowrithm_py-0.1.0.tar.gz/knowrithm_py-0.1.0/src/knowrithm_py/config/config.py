

import os


class Config:
    BASE_URL = os.get_env("BASE_URL")
    