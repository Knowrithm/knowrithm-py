

import os


class Config:
    KNOWRITHM_BASE_URL = os.getenv("KNOWRITHM_BASE_URL")
    